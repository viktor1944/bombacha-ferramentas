// CONFIGURAÇÃO DO SITE — BOMBACHA FERRAMENTAS
window.BOMBACHA_CONFIG = {
  DOWNLOAD_URL: "https://github.com/viktor1944/bombacha-ferramentas/releases/latest/download/Bombacha_Ferramentas_Recorta_Facil_Setup_v1.0.5.3_Offline_MP3_Corrigido.exe",
  VERSION: "1.0.5.3",
  FILE_SIZE: "72 MB",
  SHA256: "eea300c4d559fcb62f1426635a0400abefe5e99bf11ecb2401dbed9f8bc1dab7",
  UPDATED_AT: "31/07/2026",
  CONTACT_EMAIL: ""
};
